Jumper - Team Challenge Project

Authors:  
Sully Udall  
Nazanal Laughlin  
David Mumford  
Felipe Goncalves
